<?php
$points=0;
if(isset($_GET['x1'])){
	$a = $_GET['x1'];
	$points = $points + 15*$a;
}
if (isset($_GET['x2'])) {
	$b = $_GET['x2'];
	$points = $points + 10*$b;
}
if (isset($_GET['x3']) && isset($_GET['x4'])) {
	$c = $_GET['x3'];
	$d = $_GET['x4'];
	$points = $points + 10*($c+$d);
}
echo $points;
?>