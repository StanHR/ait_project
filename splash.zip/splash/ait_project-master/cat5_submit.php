<?php

session_start();
$_SESSION['id'] = 'harshit008';
if(!$_SESSION['id']){
	print("Please log into your account.");
}
else{
	include("db_conn.php");
	$teacher_id = $_SESSION['id'];
	$count = $_GET['a'];
	$orientation_prog_duration = $count[0];
	$orientation_prog_desc = $_GET['b'];
	$sttp_duration = $count[2];
	$sttp_desc = $_GET['c'];
	$workshop_duration = $count[4];
	$workshop_desc = $_GET['d'];
	$refresher_course_duration = $count[6];
	$refresher_course_desc = $_GET['e'];
	$fdp_duration = $count[8];
		$fdp_desc = $_GET['f'];
	$soft_skillsDP_duration = $count[10];
	$soft_skillsDP_desc = $_GET['g'];
	$seminars_duration = $count[12];
	$seminars_desc = $_GET['h'];
	$points_achieved = $_GET['points'];
	$rows = $_GET['rows'];
	//test data ends
	echo $count;
	echo "<br>".$count[0],$count[1],$count[2],$count[3],$count[4],$count[5],$count[6];
	$statement = "INSERT INTO cat5(teacher_id, orientation_prog_duration, orientation_prog_desc, sttp_duration, sttp_desc, workshop_duration, workshop_desc, refresher_course_duration, refresher_course_desc, fdp_duration, fdp_desc, soft_skillsDP_duration, soft_skillsDP_desc, seminars_duration, seminars_desc, points_achieved) values ('$teacher_id', '$orientation_prog_duration', '$orientation_prog_desc', '$sttp_duration', '$sttp_desc', '$workshop_duration', '$workshop_desc', '$refresher_course_duration', '$refresher_course_desc', '$fdp_duration', '$fdp_desc', '$soft_skillsDP_duration', '$soft_skillsDP_desc', '$seminars_duration', '$seminars_desc', '$points_achieved')";

	print($statement);
	$sql_result = mysqli_query($conn, $statement);

	if(!$sql_result){
		print("Some error in query");
	}
	else{
		print("Success");
	}
}

?>
