<script type="text/javascript">
	document.write(x1);
</script>