<!DOCTYPE html>
<html>
<title>Category</title>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {box-sizing: border-box}

/* Set height of body and the document to 100% */
body, html {
    height:160%;
    margin: 0;
    font-family: Arial;
}

/* Style tab links */
.tablink {
    background-color: #555;
    color: white;
    float: left;
    border: none;
    outline: none;
    cursor: pointer;
    padding: 14px 16px;
    font-size: 17px;
    width: 14.2857%;
}

.tablink:hover {
    background-color: #777;
}

/* Style the tab content (and add height:100% for full page content) */
.tabcontent {
    color:'powderblue';
    display: none;
    padding: 100px 20px;
    height: 120%;
}

#Category1 {background-color: powderblue;}
#Category2 {background-color: powderblue;}
#Category3 {background-color: powderblue;}
#Category4 {background-color: powderblue;}
#Category5 {background-color: powderblue;}
#Category6 {background-color:powderblue;}
#Summary {background-color: powderblue;}
</style>
</head>

<body style="background-color:#5CB8C5"><center>
<b><p style="font-size:160%; color:white ;">Performance  Appraisal  Record<p><b></center>

<button class="tablink" onclick="openPage('Category1', this, 'powderblue')" >Category 1</button>
<button class="tablink" onclick="openPage('Category2', this, 'powderblue')">Category 2</button>
<button class="tablink" onclick="openPage('Category3', this, 'powderblue')">Category 3</button>
<button class="tablink" onclick="openPage('Category4', this, 'powderblue')">Category 4</button>
<button class="tablink" onclick="openPage('Category5', this, 'powderblue')">Category 5</button>
<button class="tablink" onclick="openPage('Category6', this, 'powderblue')">Category 6</button>
<button class="tablink" onclick="openPage('Summary', this, 'powderblue')">Summary</button>

<div id="Category1" class="tabcontent">
  <iframe src="ait_project-master/category1.html" width="100%" height="100%"></iframe>
</div>

<div id="Category2" class="tabcontent">
<iframe src="ait_project-master/category2.html" width="100%" height="100%"></iframe>
</div>

<div id="Category3" class="tabcontent">
  <iframe src="ait_project-master/category3_1.html" width="100%" height="100%"></iframe>
</div>

<div id="Category4" class="tabcontent">
 <iframe src="ait_project-master/SDC-4.html" width="100%" height="100%"></iframe>
</div>

<div id="Category5" class="tabcontent">
  <iframe src="ait_project-master/category5.html" width="100%" height="100%"></iframe>
</div>

<div id="Category6" class="tabcontent">
  <iframe src="ait_project-master/catmod6.html" width="100%" height="100%"></iframe>
</div>

<div id="Summary" class="tabcontent">
  <iframe src="ait_project-master\evaluation.html" width="100%" height="100%"></iframe>
</div>

<script>
function openPage(pageName,elmnt,color) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablink");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].style.backgroundColor = "";
    }
    document.getElementById(pageName).style.display = "block";
    elmnt.style.backgroundColor = '#000000';

}
// Get the element with id="defaultOpen" and click on it
//document.getElementById("defaultOpen").click();
</script>
     
</body>


</html> 
