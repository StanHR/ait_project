<?php

session_start();
$_SESSION['id'] = 'harshit008';
if(!$_SESSION['id']){
	print("Please log into your account.");
}
else{
	$id = $_SESSION['id'];
	include("db_conn.php");
	$teacher_id = $_SESSION['id'];

	$teacher_id = $GET[''];
	$t2_lesson_planning =  $GET[''];
	$t2_effective_comm = $GET[''];
	$t2_class_control = $GET[''];
	$t2_student_involvement = $GET[''];
	$t2_media_usage = $GET[''];
	$t2_uniform_coverage = $GET[''];
	$t2_pracs_tuts = $GET[''];
	$t2_books_usage = $GET[''];
	$t3_journal_checking = $GET[''];
	$t3_profile_record_keeping = $GET[''];
	$t3_answerbook_assessment = $GET[''];
	$t3_invigilation = $GET[''];
	$total_points = $GET[''];

	//test data ends
	$statement = "INSERT INTO cat1(teacher_id, t2_lesson_planning, t2_effective_comm, t2_class_control, t2_student_involvement, t2_media_usage, t2_uniform_coverage, t2_pracs_tuts, t2_books_usage, t3_journal_checking, t3_profile_record_keeping, t3_answerbook_assessment, t3_invigilation, total_points) values ('$teacher_id', '$t2_lesson_planning', '$t2_effective_comm', '$t2_class_control', '$t2_student_involvement', '$t2_media_usage', '$t2_uniform_coverage', '$t2_pracs_tuts', '$t2_books_usage', '$t3_journal_checking', '$t3_profile_record_keeping', '$t3_answerbook_assessment', '$t3_invigilation', '$total_points')";

	print($statement);
	$sql_result = mysqli_query($conn, $statement);

	if(!$sql_result){
		print("Some error in query");
	}
}

?>